
# "Probabilistic Machine Learning: Advanced Topics" by Kevin Murphy.


This repo is used to store the pdf for 
<a href="https://probml.github.io/pml-book/book2.html">book 2</a>
(see "releases" tab on RHS).
This lets me keep track of downloads and issues
in a way which can be tracked separately from 
<a href="https://probml.github.io/pml-book/book1.html">book 1</a>. 

